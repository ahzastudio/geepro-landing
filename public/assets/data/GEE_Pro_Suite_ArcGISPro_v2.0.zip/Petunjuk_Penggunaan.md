
# Petunjuk Penggunaan ArcGIS Pro GEE Catalog Toolbox

Toolbox ini memungkinkan Anda mencari, memvisualisasikan, dan mengunduh data dari Google Earth Engine langsung di ArcGIS Pro.

## Lokasi File
`D:\AHZASTUDIO WEB ID\GOOGLE EARTHENGINE\ArcGISPro_GEE_Toolbox\`

## Persyaratan Awal (Instalasi)
Toolbox ini membutuhkan library Python `earthengine-api`.

**METODE OTOMATIS (Direkomendasikan):**
1. Cukup jalankan Tool **"0. Install / Repair Dependencies"**.
2. Tool ini **Tidak Memiliki Parameter**, langsung klik **Run**.
3. Jika library belum terinstal, tool akan mencoba menginstalnya secara otomatis.
3. Jika berhasil, Anda akan diminta me-Restart ArcGIS Pro.

**METODE MANUAL (Jika Otomatis Gagal):**
Biasanya gagal karena Environment Python default bersifat *Read-Only*.
1. Pergi ke **Settings** -> **Python**.
2. Klik **Manage Environments** -> **Clone Default**.
3. Aktifkan environment baru tersebut.
4. Klik **Add Packages**, cari `earthengine-api` dan Install.
5. Restart ArcGIS Pro.

## Cara Menggunakan Toolbox
1. Di ArcGIS Pro, buka panel **Catalog**.
2. Klik kanan pada **Toolboxes** -> **Add Toolbox**.
3. Arahkan ke folder `ArcGISPro_GEE_Toolbox` dan pilih file `GEE_Data_Catalog.pyt`.
4. Anda akan melihat 4 tool berikut:

### 1. Inisialisasi GEE
*   **Fungsi**: Membuka koneksi ke Google Earth Engine.
*   **Cara Pakai**: Jalankan tool ini setiap kali Anda baru membuka ArcGIS Pro.
*   **Fitur Autentikasi Satu Kali**: Jika Anda memasukkan Project ID, sistem akan menyimpannya. Di sesi berikutnya, cukup biarkan kosong dan jalankan tool.
*   Jika ini pertama kali, browser akan terbuka meminta Anda login akun Google (Gmail).

### 2. Cari Katalog Data
*   **Fungsi**: Mencari dataset (Landsat, Sentinel, dll).
*   **Fitur Baru (Smart Search)**:
    *   **Pencarian Cerdas**: Cari dengan kata terpisah (misal "Sentinel 2" mencari "Sentinel" DAN "2").
    *   **Prioritas Relevansi**: Dataset dengan nama/ID yang cocok akan muncul paling atas.
    *   **Safety Net**: Dataset penting (Sentinel-2, Landsat, SRTM) **DIJAMIN SELALU MUNCUL** di hasil pencarian, terlepas dari kondisi server katalog.
*   **Cara Pakai**: Masukkan kata kunci (misal: "Sentinel 2") -> Pilih Kategori -> Run.
*   **Salin ID**: Ambil ID dataset dari pesan hasil (Panel Messages).

### 3. Tambahkan Layer GEE ke Peta (Preview)
Menampilkan citra dari Earth Engine langsung ke peta ArcGIS Pro (XYZ Tiles).

**Parameter:**
1.  **Cari Dataset (Opsional)**: Ketik kata kunci (misal: "Sentinel") untuk memunculkan dropdown.
2.  **Pilih Dataset (ID)**: Pilih dari dropdown `Judul Dataset | ID`.
    *   **Tips Input Manual**: Jika dataset yang dicari tidak ada di dropdown, **HAPUS/KOSONGKAN kolom pencarian**. Dropdown akan hilang dan Anda bisa **Paste ID Manual** di kotak tersebut.
3.  **Parameter Visualisasi (JSON)**: _(Opsional)_ Konfigurasi band & warna.
    *   *Tips*: Jika muncul error "No band named", berarti dataset tersebut bukan citra optis standar (mungkin Cloud Score). Gunakan ID `COPERNICUS/S2_SR_HARMONIZED` untuk Sentinel-2 standar.
4.  **Tanggal**: Filter rentang waktu.

### 4. Download Data GEE (Export)
Mengunduh data GEE sebagai file GeoTIFF ke komputer lokal.

**Parameter:**
1.  **Cari & Pilih Dataset**: Sama seperti tool nomor 3.
2.  **Area of Interest (AOI)**: Layer poligon batas area unduhan.
3.  **Scale**: Resolusi output dalam meter.
    *   10m (Sentinel), 30m (Landsat/SRTM), 250m (MODIS).

> [!WARNING]
> **PENTING: Batasan Download GEE**
> Google membatasi "Direct Download" maksimal **32.768 x 32.768 piksel** per gambar.
>
> Jika muncul error: **"Pixel grid dimensions must be less than or equal to 32768"**:
> 1.  **Naikkan Scale**: Ubah resolusi jadi lebih kasar (misal: 10m -> 30m).
> 2.  **Perkecil Area AOI**: Gunakan batas area yang lebih sempit (misal per Kecamatan).

4.  **Folder & Nama File**: Lokasi penyimpanan hasil.

**Catatan:**
- Tool akan otomatis melakukan **Mosaic** (menggabungkan citra) jika dataset berupa ImageCollection.
- File output mungkin berupa ZIP jika GEE memecahnya menjadi per-band. Silakan ekstrak.

### 5. Analisis Risiko Erosi (RUSLE)
Tool otomatis untuk menghitung tingkat bahaya erosi dan estimasi erosi tanah (ton/ha/tahun).

**Fitur:**
*   Menggunakan Model RUSLE (Revised Universal Soil Loss Equation): `A = R * K * LS * C * P`.
*   **Otomatis**: Mengambil data curah hujan (CHIRPS), tanah (FAO), topografi (NASADEM), dan vegetasi (Sentinel-2) secara otomatis.
*   **Klasifikasi**: Mengelompokkan hasil ke dalam 5 kelas risiko sesuai SK Dirjen RRL 1998.

**Cara Pakai:**
1.  **AOI**: Masukkan poligon batas area studi.
2.  **Periode**: Tentukan tanggal mulai dan selesai (idealnya >1 tahun untuk data hujan yang valid).
3.  **Output**: Hasil berupa peta raster (.tif) dengan nilai 1-5 (tingkat risiko) dan laporan luasan per kelas di panel Messages.
